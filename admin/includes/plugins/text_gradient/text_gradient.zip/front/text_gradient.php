<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Front: Runtime Text Color Gradient Class
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class text_gradient extends plugins_base {

    // Compatibility constructor
    function text_gradient() {
      extract(tep_load('defs'));

      parent::plugins_base();
      // Load plugin configuration settings
      $this->options = $this->load_options();

      if( !$this->options['front_all'] && !isset($this->options['front_scripts'][$cDefs->script]) ) {
        $this->change(false);
      }
    }

    function html_start() {
      extract(tep_load('defs'));

      $cDefs->media[] = '<script type="text/javascript" src="' . $this->web_path . 'gradient/jquery.textgrad0.js"></script>';
      return true;
    }

    function html_end() {
      extract(tep_load('defs'));

      $contents = '';
      $launcher = $this->fs_path . 'gradient/launcher.tpl';
      $result = tep_read_contents($launcher, $contents);

      if($result) {
        if( isset($this->options['front_scripts'][$cDefs->script]) ) {
          $selector = $this->options['front_scripts'][$cDefs->script]['selector'];
          $colors = $this->options['front_scripts'][$cDefs->script]['colors'];

          $colors_array = explode('|',$colors);
          $contents_array = array(
            'TEXT_GRADIENT_SELECTOR' => $selector,
            'TEXT_GRADIENT_START' => $colors_array[0],
            'TEXT_GRADIENT_END' => $colors_array[1],
          );
          $cDefs->media[] = tep_templates_replace_entities($contents, $contents_array);
        }
        if( $this->options['front_all'] ) {
          $selector = $this->options['front_common_selector'];
          $colors = $this->options['front_common_colors'];
          $colors_array = explode('|',$colors);
          $contents_array = array(
            'TEXT_GRADIENT_SELECTOR' => $selector,
            'TEXT_GRADIENT_START' => $colors_array[0],
            'TEXT_GRADIENT_END' => $colors_array[1],
          );
          $cDefs->media[] = tep_templates_replace_entities($contents, $contents_array);
        }
      }
      return $result;
    }
  }
?>
