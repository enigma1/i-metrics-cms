<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Plugin Admin: History plugin run-time script
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class admin_history_system extends plugins_base {
    var $exclusion_array, $history_array;

    // Compatibility constructor
    function admin_history_system() {
      parent::plugins_base();

      $this->exclusion_array = array(
        'selected_box' => ''
      );

      // Load plugin configuration settings
      $this->options = $this->load_options();
      $this->strings = tep_get_strings($this->admin_path . 'back/admin_strings.php');
    }

    // The handlers called by the plugins_admin.php
    function init_late() {
      extract(tep_load('sessions'));
      $this->history_array =& $cSessions->register('g_navigation', array());
    }

    function html_left_last() {
      $cStrings =& $this->strings;

      $heading = array();
      $contents = array();

      $tmp_array = $this->get_history();
      $j=count($tmp_array);
      if( $j ) {
        $tmp_array = array_reverse($tmp_array);
        $heading[] = array('text' => $cStrings->BOX_HEADING_HISTORY);
        for($i=0; $i<$j; $i++) {
          $contents[] = array('text' => '<a href="' . $tmp_array[$i]['link'] . '" title="' . $tmp_array[$i]['link'] . '">' . $tmp_array[$i]['title'] . '</a>');
        }
        $box = new box;
        echo $box->menuBox($heading, $contents);
      }
    }

    // The Run-Time/Implementation Functions of this plugin
    function reset() {
      $this->history_array = array();
    }

    function get_history($script='') {
      if( empty($script) ) {
        return $this->build();
      }
      $result_array = array();
      foreach( $this->history_array as $key => $value ) {
        if( $value['page'] == $script ) {
          $result_array[$key] = $value;
        }
      }
      return $this->build($result_array);
    }

    function build($history_array='') {
      $result_array = array();
      if(!is_array($history_array)) $history_array = $this->history_array;

      foreach($history_array as $key => $value ) {
        $result_array[] = array( 'title' => $value['title'], 'link' => tep_href_link($value['page'], $value['params']));
      }
      return $result_array;
    }

    function add_current_page($title='', $params='', $post_check=true) {
      extract(tep_load('defs'));

      if( empty($title) && defined('HEADING_TITLE') ) {
        $title = HEADING_TITLE;
      } elseif( empty($title) ) {
        $title = $cDefs->script;
      }
      $this->add_page($cDefs->script, $title, $params, $post_check);
    }

    function add_page($page, $title, $params, $post_check=true) {
      if( $post_check && !empty($_POST) ) return;

      $tmp_array = tep_get_string_parameters($params);
      $tmp_array = $this->exclude_params($tmp_array);
      ksort($tmp_array);
      $params = tep_params_to_string($tmp_array);

      $key = md5($page.$params);
      if( isset($this->history_array[$key]) ) {
        unset($this->history_array[$key]);
      }
      $this->history_array[$key] = array(
        'page' => $page, 
        'title' => $title, 
        'params' => $params
      );
      if( count($this->history_array) > $this->options['limit'] ) {
        array_shift($this->history_array);
      }
    }

    function remove_current_page($params='') {
      extract(tep_load('defs'));
      $this->remove_page($cDefs->script, $params);
    }

    function remove_page($page, $params='') {
      if( empty($params) ) {
        foreach($this->history_array as $key => $value) {
          if( $page == $value['page'] ) {
            unset($this->history_array[$key]);
          }
        }
      } else {
        $params = tep_sort_parameter_string($params);
        $key = md5($page.$params);
        if( isset($this->history_array[$key]) ) {
          unset($this->history_array[$key]);
        }
      }
    }

    function exclude_params($input_array) {
      extract(tep_load('sessions'));

      $result_array = array();
      foreach($input_array as $key => $value) {
        if( $cSessions->is_registered($key) ) continue;
        if( isset($this->exclusion_array[$key]) ) {
          if( empty($this->exclusion_array[$key]) ) continue;
          if( $this->exclusion_array[$key] == $value ) continue;
        }
        $result_array[$key] = $value;
      }
      return $result_array;
    }
  }
?>
