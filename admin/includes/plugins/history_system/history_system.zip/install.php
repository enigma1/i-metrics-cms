<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Admin: Install class for the demo message
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class install_history_system extends plug_manager {

    // Compatibility constructor
    function install_history_system() {
      parent::plug_manager();

      $this->options_array = array(
        'limit' => 4
      );

      // Never set the key member
      $this->title = 'History System';
      $this->author = 'Mark Samios';
      $this->version = '1.01';
      $this->framework = '1.12';
      $this->help = '';
      tep_read_contents($this->admin_path.'readme.txt', $this->help);
      $this->front = 0;
      $this->back = 1;
      $this->status = 1;
      $this->default_limit = 4;

      // Key/Left => Source Path/File (to copy file from)
      // Value/Right => Destination Path only (to copy source file to)
      $this->files_array = array(
      );

      $this->admin_files_array = array(
      );

      $this->config_form = $this->admin_path . 'config_form.tpl';
      $this->strings = tep_get_strings($this->admin_path . 'strings.php');
    }

    function set_options() {
      extract(tep_load('defs'));
      $cStrings =& $this->strings;

      // Read the plugin store options into an array
      $options_array = $this->load_options();
      $limit = ($options_array['limit'] > 1)?$options_array['limit']:$this->default_limit;

      $html_string = '';
      if( !is_file($this->config_form) ) {
        $html_string = sprintf($cStrings->ERROR_PLUGIN_INVALID_CONFIG_TPL, $this->config_form);
        return $html_string;
      }
      require_once($this->config_form);
      return $html_string;
    }

    function process_options() {
      extract(tep_load('defs', 'message_stack'));
      $cStrings =& $this->strings;

      $error = false;      

      $options_array = array(
        'limit' => ((isset($_POST['limit']) && $_POST['limit'] > 1 && $_POST['limit'] < 100)?(int)$_POST['limit']:$this->default_limit),
      );

      // Store user options
      $this->save_options($options_array);
      $msg->add_session(sprintf($cStrings->SUCCESS_PLUGIN_RECONFIGURED, $this->title), 'success');
      tep_redirect(tep_href_link($cDefs->script, tep_get_all_get_params(array('action')) . 'action=set_options'));
    }

    function install() {
      $result = parent::install();
      $this->save_options($this->options_array);
      return $result;
    }

    function uninstall() {
      extract(tep_load('sessions'));
      $cSessions->unregister('g_navigation');
      parent::uninstall();
    }
  }
?>
