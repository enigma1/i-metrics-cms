<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software - Innovation & Excellence
// Author: Mark Samios
// http://www.asymmetrics.com
// Admin Plugin: Right Column Options Strings
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//----------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
$HEADING_CONFIGURATION_OPTIONS        = 'Options';
$TEXT_HISTORY_LIMIT                   = 'History Limit';

$ERROR_PLUGIN_HISTORY_LIMIT_MISSING   = 'History Limit must be specified';
$ERROR_PLUGIN_HISTORY_LIMIT_INVALID   = 'Invalid Historry Limit specified';
$SUCCESS_PLUGIN_RECONFIGURED          = 'New options set for %s';
?>