<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2011 Asymmetric Software - Innovation & Excellence
// Author: Mark Samios
// http://www.asymmetrics.com
// Admin Install Plugin: Code Tags Install Strings
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//----------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
$TEXT_SELECT_TEMPLATE                = 'Please Select a template:';
$TEXT_ADDITIONAL_TEMPLATE_FILES      = 'Additional Template files will be installed based on your selection.';
$TEXT_ADDITIONAL_TEMPLATE_FILES_REV  = 'Template files will be reverted based on your selection.';
?>