<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Front: Runtime Code Tags Class
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class code_tags extends plugins_base {
    // Force this plugin to operate only with the following scripts
    var $scripts_array = array(
      FILENAME_GENERIC_PAGES,
    );

    // Compatibility constructor
    function code_tags() {
      parent::plugins_base();
    }

    function html_start() {
      extract(tep_load('defs'));

      $cDefs->media[] = '<link rel="stylesheet" type="text/css" href="' . $this->web_template_path . 'code_tags.css" />';
      return true;
    }
  }
?>
