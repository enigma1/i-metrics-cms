<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Admin Plugin: Install Class for the Code Tags
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
  class install_code_tags extends plug_manager {
    // Compatibility constructor
    function install_code_tags() {
      parent::plug_manager();

      $front_defs = tep_web_files('FILENAME_GENERIC_PAGES');
      // Default Options
      $this->options_array = array(
        'template'             => 'stock',
        'fscripts'             => array_values($front_defs)
      );

      // Never set the key member
      $this->title = 'Code Tags';
      $this->author = 'Mark Samios';
      $this->version = '1.00';
      $this->framework = '1.12';
      $this->help = ''; // Brief description of a plugin or use a file
      tep_read_contents($this->admin_path.'readme.txt', $this->help);
      $this->front = 1;
      $this->back = 0;
      $this->status = 1;
      $this->template_path = 'front/templates/';
      // The array of files that operate on the web-front
      // Left(Key)     => Source File with Path relative to the plugins directory (to copy file from)
      // Right(Value)  => Destination Path and File (to copy source file to)
      $this->files_array = array(
        'front/code_tags.php'             => $this->web_path.'code_tags.php',
      );

      // The array of files that operate on the administration end
      // Left(Key)     => Source Path/File (to copy file from)
      // Right(Value)  => Destination Path only (to copy source file to)
      $this->admin_files_array = array(
      );

      // Common Template filenames
      $this->template_array = array(
        'code_tags.css'                  => $this->web_template_path.'code_tags.css',
        'code-php1.png'                  => $this->web_template_path.'code-php1.png',
        'code-php2.png'                  => $this->web_template_path.'code-php2.png',
        'code-php3.png'                  => $this->web_template_path.'code-php3.png',
      );

      $this->strings = tep_get_strings($this->admin_path . 'strings.php');
    }

    function install() {
      $this->set_posted_template();
      $result = parent::install();
      $this->save_options($this->options_array);
      return $result;
    }

    function uninstall() {
      $options_array = $this->load_options();
      $this->load_template_files($options_array['template']);
      parent::uninstall();
      return true;
    }

    function pre_install() {
      return $this->common_select();
    }
    function pre_copy_front() {
      return $this->common_select();
    }
    function pre_revert() {
      return $this->common_select(true);
    }

    function pre_uninstall() {
      $options_array = $this->load_options();
      $this->load_template_files($options_array['template']);
      return true;
    }
    function re_copy_front() {
      $this->set_posted_template();
      return parent::re_copy_front();
    }
    function revert_files() {
      $this->set_posted_template(false);
      return parent::revert_files();
    }

    function common_select($revert=false) {
      $cStrings =& $this->strings;

      $tmp_array = $this->get_templates();
      if( !count($tmp_array) ) return false;

      echo '<div class="comboHeading">' . "\n";
      echo '<label class="heavy" for="template_select">' . $cStrings->TEXT_SELECT_TEMPLATE . '</label><span class="hpad">' . tep_draw_pull_down_menu('template', $tmp_array, $this->options_array['template'], 'id="template_select"') . '</span>';
      if( $revert ) {
        echo $cStrings->TEXT_ADDITIONAL_TEMPLATE_FILES_REV;
      } else {
        echo $cStrings->TEXT_ADDITIONAL_TEMPLATE_FILES;
      }
      echo '</div>' . "\n";

      return true;
    }
  }
?>
