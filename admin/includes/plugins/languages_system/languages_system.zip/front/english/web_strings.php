<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2011 Asymmetric Software - Innovation & Excellence
// Author: Mark Samios
// http://www.asymmetrics.com
// Front Plugin: Strings for the languages system
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//----------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
$BOX_HEADING_SELECT_LANGUAGE         = 'Select Language';

$ERROR_PLUGIN_INVALID_LANGUAGE       = 'Invalid language specified';
$SUCCESS_PLUGIN_LANGUAGE_CHANGED     = 'Language Changed to %s';
?>