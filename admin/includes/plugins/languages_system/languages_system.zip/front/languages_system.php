<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2011 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Front: Languages system selection
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
  class languages_system extends plugins_base {
    // Compatibility constructor
    function languages_system() {
      // Call the parent to set operation path and activation conditions
      parent::plugins_base();
      // Load plugin configuration settings
      $this->options = $this->load_options();
      // Load the plugin strings
      $strings_array = array('web_strings.php');
      $this->strings = $this->load_strings($strings_array);
      // Initialize the template
      $this->language_template = $this->fs_template_path . 'languages_form.tpl';

      $this->icons_array = $this->get_icons();

      if( count($this->icons_array) < 2 ) {
        $this->change(false);
      }
    }

    function plugin_form_process() {
      extract(tep_load('defs', 'languages', 'http_validator', 'database', 'validator', 'message_stack'));

      if( !isset($_POST[$lng->name]) ) return false;

      $cStrings =& $this->strings;
      // Make sure the language system has sent the new cookie if applicable
      $http->send_cookies();
      // Get validated parameters only for the language switch
      $params = $cValidator->convert_to_get(array('action'));
      // Force language switching
      tep_redirect(tep_href_link($cDefs->script, $params));
    }

    function html_header_top() {
      if( !$this->options['display_top'] ) return false;
      return $this->display_common(0);
    }
    function html_left() {
      if( !$this->options['display_left'] ) return false;
      return $this->display_common(1);
    }
    function html_right() {
      if( !$this->options['display_right'] ) return false;
      return $this->display_common(2);
    }

    function display_common($pos) {
      extract(tep_load('defs', 'languages', 'database', 'validator', 'message_stack'));

      $cStrings =& $this->strings;
      $params = $cValidator->convert_to_get(array('action'), array('action' => 'plugin_form_process'));
      $link = tep_href_link($cDefs->script, $params);
      $this->language_template = $pos?($this->fs_template_path . 'languages_form.tpl'):($this->fs_template_path . 'languages_head_form.tpl');
      require($this->language_template);
      return true;
    }

    function get_icons() {
      extract(tep_load('languages'));
      $result_array = array();

      foreach($lng->languages as $key => $value) {
        $icon = DIR_WS_STRINGS . tep_trail_path($value['language_path']) . 'images/icon.png';
        if( is_file($icon) ) {
          $result_array[$value['language_name']] = array(
            'id'=> $key, 
            'icon' => $icon
          );
        }
      }
      return $result_array;
    }
  }
?>
