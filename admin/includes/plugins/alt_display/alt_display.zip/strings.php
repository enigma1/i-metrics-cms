<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software - Innovation & Excellence
// Author: Mark Samios
// http://www.asymmetrics.com
// Admin Plugin: Install/Config Text Color Gradient strings file
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//----------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
$HEADING_DISPLAY_OPTIONS              = 'Display Options';

$TEXT_SELECT_TEMPLATE                 = 'Please Select a template:';
$TEXT_ADDITIONAL_TEMPLATE_FILES       = 'Additional Template files will be installed based on your selection.';

$TEXT_PRN_TEXT_PAGES                  = 'Display Print Option on Text Pages';
$TEXT_PRN_TEXT_COLLECTIONS            = 'Display Print Option on Text Collections';

$TEXT_RSS_TEXT_COLLECTIONS            = 'Display RSS Option on Text Collections';
$TEXT_RSS_IMAGE_COLLECTIONS           = 'Display RSS Option on Text Collections';

$TEXT_PDF_TEXT_PAGES                  = 'Display PDF Option on Text Pages';
$TEXT_PDF_TEXT_COLLECTIONS            = 'Display PDF Option on Text Collections';
$TEXT_PDF_IMAGE_COLLECTIONS           = 'Display PDF Option on Text Collections';

$SUCCESS_PLUGIN_RECONFIGURED          = 'New options set for %s';
?>