<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2011 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Front: Runtime Text Color Gradient Class
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
  class alt_display extends plugins_base {
    // Compatibility constructor
    function alt_display() {
      $this->post_request = false;
      $this->buttons_array = array();
      $this->handler_array = array(
        'prn_'
        //'rss_',
        //'pdf_',
      );
      parent::plugins_base();
      // Load plugin configuration settings
      $this->options = $this->load_options();
      // Load the plugin specific strings
      $strings_array = array('web_strings.php');
      $this->strings = $this->load_strings($strings_array);

      $result = true;

      for($i=0, $j=count($this->handler_array); $i<$j; $i++) {
        $key = $this->handler_array[$i] . $this->key;
        if( tep_check_submit($key) ) {
          $this->post_request = $this->handler_array[$i];
          break;
        }
        $this->buttons_array[$this->handler_array[$i]] = $key;
      }

      $this->alt_form = $this->fs_template_path . 'alt_display.tpl';
      $this->alt_content = $this->fs_template_path . 'alt_content.tpl';

      if( !file_exists($this->alt_form) ) $result = false;
      $this->change($result);
    }


    function init_late() {
      $result = false;

      for($i=0, $j=count($this->handler_array); $i<$j; $i++) {
        $key = $this->handler_array[$i];
        if( $this->check_page($this->handler_array[$i]) || $this->check_collection($this->handler_array[$i]) ) {
          $result = true;
          break;
        }
      }
      $this->change($result);
      return $result;
    }


    function html_main_content_end() {
      extract(tep_load('defs', 'validator', 'database'));

      if( $this->post_request ) return false;

      $cStrings =& $this->strings;

      if( $cDefs->gtext_id ) {
        $desc_query = $db->fly("select gtext_title from " . TABLE_GTEXT . " where gtext_id = '" . (int)$cDefs->gtext_id . "'");
        $desc_array = $db->fetch_array($desc_query);
        $desc = $desc_array['gtext_title'];
      } else {
        $desc_query = $db->fly("select abstract_zone_name from " . TABLE_ABSTRACT_ZONES . " where abstract_zone_id = '" . (int)$cDefs->abstract_id . "'");
        $desc_array = $db->fetch_array($desc_query);
        $desc = $desc_array['abstract_zone_name'];
      }

      $params = $cValidator->convert_to_get(array('action'), array('action' => 'plugin_form_process'));
      $link = tep_href_link($cDefs->script, $params);
      require($this->alt_form);
      return true;
    }

    function html_start() {
      if( !$this->post_request) return false;

      ob_start();
      return true;
    }

    function html_start_sub2() {
      extract(tep_load('defs', 'database', 'sessions'));

      if( !$this->post_request) return false;

      ob_end_clean();

      $sub_array = array();
      if( $cDefs->gtext_id ) {
        $content_query = $db->fly("select gtext_title as title, gtext_description as description from " . TABLE_GTEXT . " where gtext_id = '" . (int)$cDefs->gtext_id . "'");
        $content_array = $db->fetch_array($content_query);
      } else {
        $content_query = $db->fly("select abstract_zone_name as title, abstract_zone_desc as description from " . TABLE_ABSTRACT_ZONES . " where abstract_zone_id = '" . (int)$cDefs->abstract_id . "'");
        $content_array = $db->fetch_array($content_query);
        $cText = new gtext_front;
        $tmp_array = $cText->get_entries($cDefs->abstract_id);

        foreach($tmp_array as $value) {
          $sub_array[] = array(
            'title' => $value['gtext_alt_title'], 
            'description' => strip_tags(tep_truncate_string($value['gtext_description'])),
          );
        }
      }

      ob_start();
      require($this->alt_content);

      $contents = ob_get_contents();
      ob_end_clean();

      echo $contents;

      $cSessions->close();
      return true;
    }
/*

    function html_start_sub1() {
      global $html_start_sub1;
      if( $this->post_request !== false) {
        $html_start_sub1 = array();
      }
      return true;
    }

    function html_start_sub2() {
      global $html_start_sub2;
      if( $this->post_request !== false) {
        $html_start_sub2 = array();
      }
      return true;
    }

    function html_body_header() {
      global $html_body_header;
      if( $this->post_request !== false) {
        $html_body_header = array();
      }
      return true;
    }

    function html_content_bottom() {
      global $html_content_bottom;
      if( $this->post_request !== false) {
        $html_content_bottom = array();
      }
      return true;
    }

    function html_end() {
      global $html_end;
      if( $this->post_request !== false) {
        $html_end = array();
      }
      return true;
    }
*/

    function check_page($key) {
      extract(tep_load('defs'));

      //$key = $this->handle_request;
      $result = false;
      if( empty($key) || !$cDefs->gtext_id ) return $result;
      return (isset($this->options[$key . 'text_pages']) && $this->options[$key . 'text_pages']);
    }

    function check_collection($key) {
      extract(tep_load('defs'));

      //$key = $this->handle_request;
      $result = false;
      if( empty($key) || !$cDefs->abstract_id ) return $result;

      $cAbstract = new abstract_front();
      $zone_class = $cAbstract->get_zone_class($cDefs->abstract_id);
      switch($zone_class) {
        case 'generic_zones':
          $postfix = 'text_collections';
          $result = $zone_class;
          break;           
        case 'image_zones':
          $postfix = 'image_collections';
          $result = $zone_class;
          break;
        case 'super_zones':
          $postfix = 'super_collections';
          $result = $zone_class;
          break;
        default:
          break;
      }
      if( !isset($this->options[$key . $postfix]) || !$this->options[$key . $postfix]) return false;
      return $result;
    }
  }
?>
