<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Front: Runtime Text Color Gradient Class
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class alt_display extends plugins_base {
    var $post_request = false;
    var $buttons_array = array();
    var $handler_array = array(
      'prn_'
      //'rss_',
      //'pdf_',
    );

    // Compatibility constructor
    function alt_display() {
      parent::plugins_base();
      // Load plugin configuration settings
      $this->options = $this->load_options();
      // Load the plugin specific strings
      $this->strings = tep_get_strings($this->web_template_path . 'web_strings.php');

      $result = true;

      for($i=0, $j=count($this->handler_array); $i<$j; $i++) {
        $key = $this->handler_array[$i] . $this->key;
        if( tep_check_submit($key) ) {
          $this->post_request = $this->handler_array[$i];
          break;
        }
        $this->buttons_array[$this->handler_array[$i]] = $key;
      }

      $this->alt_form = $this->web_template_path . 'alt_display.tpl';
      if( !file_exists($this->alt_form) ) $result = false;
      $this->change($result);
    }


    function init_late() {
      $result = false;

      for($i=0, $j=count($this->handler_array); $i<$j; $i++) {
        $key = $this->handler_array[$i];
        if( $this->check_page($this->handler_array[$i]) || $this->check_collection($this->handler_array[$i]) ) {
          $result = true;
          break;
        }
      }
      $this->change($result);
      return $result;
    }

    function html_main_content_end() {
      global $g_db, $g_script, $g_validator, $current_gtext_id, $current_abstract_id;
      if( $this->post_request ) return false;

      $cStrings =& $this->strings;

      if( $current_gtext_id ) {
        $desc_query = $g_db->query("select gtext_title from " . TABLE_GTEXT . " where gtext_id = '" . (int)$current_gtext_id . "'");
        $desc_array = $g_db->fetch_array($desc_query);
        $desc = $desc_array['gtext_title'];
      } else {
        $desc_query = $g_db->query("select abstract_zone_name from " . TABLE_ABSTRACT_ZONES . " where abstract_zone_id = '" . (int)$current_abstract_id . "'");
        $desc_array = $g_db->fetch_array($desc_query);
        $desc = $desc_array['abstract_zone_name'];
      }
      require($this->alt_form);
      return true;
    }

    function html_start_sub1() {
      global $html_start_sub1;
      if( $this->post_request !== false) {
        $html_start_sub1 = array();
      }
      return true;
    }

    function html_start_sub2() {
      global $html_start_sub2;
      if( $this->post_request !== false) {
        $html_start_sub2 = array();
      }
      return true;
    }

    function html_body_header() {
      global $html_body_header;
      if( $this->post_request !== false) {
        $html_body_header = array();
      }
      return true;
    }

    function html_content_bottom() {
      global $html_content_bottom;
      if( $this->post_request !== false) {
        $html_content_bottom = array();
      }
      return true;
    }

    function html_end() {
      global $html_end;
      if( $this->post_request !== false) {
        $html_end = array();
      }
      return true;
    }


    function check_page($key) {
      global $current_gtext_id;

      //$key = $this->handle_request;
      $result = false;
      if( empty($key) || !$current_gtext_id ) return $result;
      return (isset($this->options[$key . 'text_pages']) && $this->options[$key . 'text_pages']);
    }

    function check_collection($key) {
      global $current_abstract_id;

      //$key = $this->handle_request;
      $result = false;
      if( empty($key) || !$current_abstract_id ) return $result;

      $cAbstract = new abstract_front();
      $zone_class = $cAbstract->get_zone_class($current_abstract_id);
      switch($zone_class) {
        case 'generic_zones':
          $postfix = 'text_collections';
          $result = $zone_class;
          break;           
        case 'image_zones':
          $postfix = 'image_collections';
          $result = $zone_class;
          break;
        case 'super_zones':
          $postfix = 'super_collections';
          $result = $zone_class;
          break;
        default:
          break;
      }
      if( !isset($this->options[$key . $postfix]) || !$this->options[$key . $postfix]) return false;
      return $result;
    }
  }
?>
