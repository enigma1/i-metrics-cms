<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Admin Plugin: Download System invoke script
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class admin_download_system extends plugins_base {

    // Compatibility constructor
    function admin_download_system() {
      $this->box = 'abstract_box';

      // Call the parent to set operation path and activation conditions
      parent::plugins_base();
      $options = $this->load_options();

      tep_define_vars($this->admin_path . 'back/admin_defs.php');
      $this->strings = tep_get_strings($this->admin_path . 'back/admin_strings.php');
    }

    function help_link() {
      extract(tep_ref('key', 'action', 'link'), EXTR_OVERWRITE|EXTR_REFS);

      $result = false;
      if( $key != $this->key ) return $result;

      $cStrings =& $this->strings;

      switch($action) {
        case 'set_options':
          $link = '<a href="' . tep_href_link(FILENAME_DOWNLOAD, 'action=help&ajax=plugin_options') . '" title="' . $cStrings->TEXT_HELP_OPTIONS . '" class="heading_help" target="_blank">' . tep_image(DIR_WS_ICONS . 'icon_help_32.png', $cStrings->TEXT_HELP_OPTIONS) . '</a>';
          $result = true;
          break;
        default:
          break;
      }
      return $result;
    }

    function abstract_box() {
      extract(tep_ref('contents'), EXTR_OVERWRITE|EXTR_REFS);
      $cStrings =& $this->strings;

      $contents[] = array('text' => '<a href="' . tep_href_link(FILENAME_DOWNLOAD, 'selected_box=' . $this->box) . '">' . $cStrings->BOX_DOWNLOAD . '</a>');
      return true;
    }

    function ajax_start() {
      extract(tep_load('defs', 'sessions'));

      $result = false;
      if( $cDefs->action != 'help' ) {
        return $result;
      }

      $result = $this->get_help();
      return $result;
    }

    function html_start() {
      extract(tep_load('defs'));

      $cDefs->media[] = '<script type="text/javascript" src="' . DIR_WS_JS . 'fancybox/jquery.fancybox-1.3.0.pack.js"></script>';
      $cDefs->media[] = '<script type="text/javascript" src="' . DIR_WS_JS . 'fancybox/jquery.mousewheel-3.0.2.pack.js"></script>';
      $cDefs->media[] = '<link rel="stylesheet" type="text/css" href="' . DIR_WS_JS . 'fancybox/jquery.fancybox-1.3.0.css" media="screen" />';
      return true;
    }

    function html_end() {
      extract(tep_load('defs'));

      $hID = (isset($_GET['hID']) ? (int)$_GET['hID'] : '');

      $contents = '';
      $launcher = $this->admin_path . 'back/launcher.tpl';
      $result = tep_read_contents($launcher, $contents);
      if( !$result ) return false;

      $contents_array = array(
        'POPUP_TITLE' => 'Help on Download System',
        'POPUP_SELECTOR' => 'div.help_page a.plugins_help',
      );
      $cDefs->media[] = tep_templates_replace_entities($contents, $contents_array);
      return true;
    }

    function html_home_plugins() {
      extract(tep_ref('entries_array'), EXTR_OVERWRITE|EXTR_REFS);
      $cStrings =& $this->strings;

      $entries_array[] = array(
        'id' => $this->key,
        'title' => $cStrings->TEXT_INFO_MESSAGE,
        'image' => tep_image($this->admin_web_path . 'download.png', $cStrings->TEXT_INFO_MESSAGE),
        'href' => tep_href_link(FILENAME_DOWNLOAD, 'action=set_options&plgID=' . $this->key . '&selected_box=plugins'),
      );
      return true;
    }

    function html_home_collections() {
      extract(tep_ref('entries_array'), EXTR_OVERWRITE|EXTR_REFS);
      $cStrings =& $this->strings;

      $entries_array[] = array(
        'id' => $this->key,
        'title' => $cStrings->TEXT_INFO_MESSAGE,
        'image' => tep_image($this->admin_web_path . 'download.png', $cStrings->TEXT_INFO_MESSAGE),
        'href' => tep_href_link(FILENAME_DOWNLOAD, 'selected_box=' . $this->box),
      );
      return true;
    }

  }
?>
