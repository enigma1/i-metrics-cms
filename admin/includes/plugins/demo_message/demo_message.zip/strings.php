<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software - Innovation & Excellence
// Author: Mark Samios
// http://www.asymmetrics.com
// Admin Plugin: Message Strings
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//----------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
$HEADING_DISPLAY_OPTIONS          = 'Display Options';
$TEXT_MESSAGE                     = 'Message to display';
$TEXT_INFO_DEFAULT                = 'Enter your message here';

$ERROR_MESSAGE_MISSING            = 'Message cannot be empty';
$ERROR_MESSAGE_LONG               = 'The message you entered is too long';
$ERROR_PLUGIN_INVALID_CONFIG_TPL  = 'Invalid or missing Configuration Template';
$SUCCESS_PLUGIN_RECONFIGURED      = 'New options set for %s';
?>