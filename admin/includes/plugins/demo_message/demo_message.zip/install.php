<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Admin: Install class for the demo message
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
*/
  class install_demo_message extends plug_manager {
    var $options_array = array(
      'message' => 'Use the plugin configuration option to set a message.'
    );

    // Compatibility constructor
    function install_demo_message() {
      parent::plug_manager();
      // Never set the key member
      $this->title = 'Demo Message'; // Text title of the Plugin shows on the admin
      $this->author = 'Mark Samios'; // Your name/author
      $this->version = '1.01'; // Plugin Version
      $this->framework = '1.11'; // Minimum version of the I-Metrics CMS required
      $this->help = ''; // Brief description of a plugin or use a file
      tep_read_contents($this->admin_path.'readme.txt', $this->help);
      $this->front = 1;  // Operates on front-end
      $this->back = 0;   // Do not operates on admin-end
      $this->status = 1; // enable plugin after installation

      // The array of files that operate on the web-front
      // Left(Key)     => Source File with Path (to copy file from)
      // Right(Value)  => Destination Path and File (to copy source file to)
      $this->files_array = array(
        'front/demo_message.php' => $this->web_path.'demo_message.php',
      );

      // The array of files that operate on the administration end
      // Left(Key)     => Source Path/File (to copy file from)
      // Right(Value)  => Destination Path only (to copy source file to)
      $this->admin_files_array = array(
      );

      // Setup plugin configuration options using a template file
      $this->config_form = $this->admin_path . 'config_form.tpl';
      // Load string for the installation/configuration from a file
      $this->strings = tep_get_strings($this->admin_path . 'strings.php');
    }

    // Show configuration options
    function set_options() {
      global $g_script;
      $cStrings =& $this->strings;
      // Read the plugin store options into an array
      $options_array = $this->load_options();
      $message = $options_array['message'];

      $html_string = '';
      if( !file_exists($this->config_form) ) {
        $html_string = sprintf($cStrings->ERROR_PLUGIN_INVALID_CONFIG_TPL, $this->config_form);
        return $html_string;
      }
      require_once($this->config_form);
      return $html_string;
    }

    // Save/Process configuration options
    function process_options() {
      global $g_db, $g_script, $messageStack;
      $cStrings =& $this->strings;

      $error = false;      
      if( !isset($_POST['message']) || empty($_POST['message']) ) {
        $messageStack->add_session($cStrings->ERROR_PLUGIN_MESSAGE_MISSING);
        $error = true;
      }
      if( tep_string_length($_POST['message']) > 255 ) {
        $messageStack->add_session($cStrings->ERROR_PLUGIN_MESSAGE_LONG);
        $error = true;
      }

      if($error) {
        tep_redirect(tep_href_link($g_script, tep_get_all_get_params(array('action')) . 'action=set_options'));
      }

      // Prepare the options array for storage
      $options_array = array(
        'message' => $g_db->filter($_POST['message']),
      );
      // Store user options
      $this->save_options($options_array);
      $messageStack->add_session(sprintf($cStrings->SUCCESS_PLUGIN_RECONFIGURED, $this->title), 'success');
    }

    // Install plugin
    function install() {
      global $g_db;
      // Do not have core files or dbase tables so let our parent do most of the work
      $result = parent::install();
      // Save the default options for this plugin
      $this->save_options($this->options_array);
      return $result;
    }

    function uninstall() {
      // Let our parent do the job
      parent::uninstall();
    }
  }
?>
