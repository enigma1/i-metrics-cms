<?php
/*
//----------------------------------------------------------------------------
// Copyright (c) 2006-2010 Asymmetric Software. Innovation & Excellence.
// Author: Mark Samios
// http://www.asymmetrics.com
//----------------------------------------------------------------------------
// Admin Plugins: Demo System invoke script
//----------------------------------------------------------------------------
// I-Metrics CMS
//----------------------------------------------------------------------------
// Script is intended to be used with:
// osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
------------------------------------------------------------------------------
// Released under the GNU General Public License
//----------------------------------------------------------------------------
//
*/
  class admin_demo_message extends plugins_base {
    var $strings;
    // Compatibility constructor
    function admin_demo_message() {
      // Call the parent to set operation path and activation conditions
      parent::plugins_base();
      $this->strings = tep_get_strings($this->admin_path . 'back/admin_strings.php');
    }

    function html_home_plugins() {
      extract(tep_ref('entries_array'), EXTR_OVERWRITE|EXTR_REFS);
      $cStrings =& $this->strings;

      $entries_array[] = array(
        'id' => $this->key,
        'title' => $cStrings->TEXT_INFO_DEMO_MESSAGE,
        'image' => tep_image($this->admin_path . 'notes.png', $cStrings->TEXT_INFO_DEMO_MESSAGE),
        'href' => tep_href_link(FILENAME_PLUGINS, 'action=set_options&plgID=' . $this->key . '&selected_box=plugins'),
      );
      return true;
    }
  }
?>
